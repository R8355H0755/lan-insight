import { MonitoringDashboard } from '@/components/MonitoringDashboard';

const Index = () => {
  return <MonitoringDashboard />;
};

export default Index;
